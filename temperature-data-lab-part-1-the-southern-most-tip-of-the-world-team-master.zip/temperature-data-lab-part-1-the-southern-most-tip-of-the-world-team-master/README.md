# Temperature-Data-Lab-Part1
 Student starter code for Part 1 of the Temperature Data Lab for EESC 4464
